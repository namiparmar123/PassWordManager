//
//  MOBILEIIP02504App.swift
//  MOBILEIIP02504
//
//  Created by Admin on 04/03/25.
//

import SwiftUI

@main
struct MOBILEIIP02504App: App {
    let persistenceController = PersistenceController.shared

        var body: some Scene {
            WindowGroup {
                PasswordListView()
                    .environment(\.managedObjectContext, persistenceController.context)
            }
        }
}
