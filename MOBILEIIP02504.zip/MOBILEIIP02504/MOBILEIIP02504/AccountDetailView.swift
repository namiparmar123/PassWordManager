//
//  SwiftUIView.swift
//  MOBILEIIP02504
//
//  Created by Admin on 04/03/25.
//

import SwiftUI

struct AccountDetailView: View {
    @State private var updatedAccountName: String
    @State private var updatedUsername: String
    @State private var updatedPassword: String
    @State private var isPasswordDecrypted: Bool = false // Track decryption state

    let passwordEntry: PasswordEntry
    @Binding var showPassword: Bool
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) var presentationMode

    init(passwordEntry: PasswordEntry, showPassword: Binding<Bool>) {
        self.passwordEntry = passwordEntry
        self._showPassword = showPassword
        _updatedAccountName = State(initialValue: passwordEntry.accountName ?? "")
        _updatedUsername = State(initialValue: passwordEntry.username ?? "")
        _updatedPassword = State(initialValue: "••••••••") // Masked password initially
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Account Details")
                .font(.title3)
                .bold()
                .foregroundColor(.blue)

            DetailRow(label: "Account Type", value: $updatedAccountName, isEditable: true)
            DetailRow(label: "Username/ Email", value: $updatedUsername, bold: true, isEditable: true)

            HStack {
                DetailRow(label: "Password", value: $updatedPassword, bold: true, isEditable: isPasswordDecrypted)

                Button(action: { togglePasswordVisibility() }) {
                    Image(systemName: isPasswordDecrypted ? "eye.slash" : "eye")
                        .foregroundColor(.gray)
                }
            }

            HStack {
                Button(action: { saveChanges() }) {
                    Text("Save")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }

                Button(action: { deletePassword() }) {
                    Text("Delete")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }

    private func togglePasswordVisibility() {
        if isPasswordDecrypted {
            updatedPassword = "••••••••" // Hide password again
        } else {
            updatedPassword = CryptoHelper.decrypt(passwordEntry.encryptedPassword ?? "") ?? "" // Use your decryption function
        }
        isPasswordDecrypted.toggle()
    }

    private func saveChanges() {
        passwordEntry.accountName = updatedAccountName
        passwordEntry.username = updatedUsername
        passwordEntry.encryptedPassword = updatedPassword // Ensure encryption if needed
        do {
            try viewContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            print("Failed to save: \(error.localizedDescription)")
        }
    }

    private func deletePassword() {
        viewContext.delete(passwordEntry)
        do {
            try viewContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            print("Failed to delete: \(error.localizedDescription)")
        }
    }

    private func decryptPassword(_ encryptedText: String) -> String {
        return  CryptoHelper.decrypt(encryptedText) ?? "" // Call your actual decryption function here
    }
}


struct DetailRow: View {
    let label: String
    @Binding var value: String // Use Binding to allow editing
    var bold: Bool = false
    var isEditable: Bool = false // Flag to control editability
    
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.caption)
                .foregroundColor(.gray)
            
            if isEditable {
                TextField("", text: $value)
                    .font(bold ? .headline : .body)
//                    .textFieldStyle(RoundedBorderTextFieldStyle()) // Adds border for better UI
            } else {
                Text(value)
                    .font(bold ? .headline : .body)
            }
        }
    }
}

