//
//  AddAccountView.swift
//  MOBILEIIP02504
//
//  Created by Admin on 04/03/25.
//

import SwiftUI

struct AddPasswordView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) var presentationMode
    
    var passwordEntry: PasswordEntry?
    
    @State private var accountName = ""
    @State private var username = ""
    @State private var password = ""
    @State private var showPassword = false  // 👀 Toggle password visibility

    var body: some View {
        VStack(spacing: 20) {
            Text(passwordEntry == nil ? "Add New Account" : "Account Details")
                .font(.title3).bold()
            
            TextField("Account Name", text: $accountName)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            TextField("Username / Email", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            if passwordEntry == nil {
                Button(action: savePassword) {
                    Text("Add New Account")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(20)
                }
            } else {
                HStack {
                    Button(action: savePassword) {
                        Text("Edit")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.black)
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    
                    Button(action: deletePassword) {
                        Text("Delete")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red)
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                }
                .padding()
            }
        }
        .padding()
        .onAppear {
            if let passwordEntry = passwordEntry {
                accountName = passwordEntry.accountName ?? ""
                username = passwordEntry.username ?? ""
                if let encrypted = passwordEntry.encryptedPassword {
                    password = CryptoHelper.decrypt(encrypted) ?? ""
                }
            }
        }
    }

    private func savePassword() {
        let context = viewContext
        let passwordData = passwordEntry ?? PasswordEntry(context: context)
        passwordData.accountName = accountName
        passwordData.username = username
        passwordData.encryptedPassword = CryptoHelper.encrypt(password)
        PersistenceController.shared.saveContext()
        presentationMode.wrappedValue.dismiss()
    }

    private func deletePassword() {
        guard let passwordEntry = passwordEntry else { return }
        viewContext.delete(passwordEntry)
        PersistenceController.shared.saveContext()
        presentationMode.wrappedValue.dismiss()
    }
}
