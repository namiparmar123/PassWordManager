//
//  ContentView.swift
//  MOBILEIIP02504
//
//  Created by Admin on 04/03/25.
//


import SwiftUI
import CoreData


struct PasswordListView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(entity: PasswordEntry.entity(), sortDescriptors: []) var passwords: FetchedResults<PasswordEntry>
    
    @State private var showAddView = false
    @State private var showDetailsView = false
    @State private var selectedPassword: PasswordEntry?

    var body: some View {
        NavigationView {
            ZStack {
                // List of saved passwords
                List {
                    ForEach(passwords, id: \.objectID) { password in
                        Button(action: {
                            selectedPassword = password
                            showDetailsView.toggle()
                        }) {
                            HStack {
                                Text(password.accountName ?? "Unknown")
                                    .font(.headline)
                                    .foregroundColor(.black)
                               
                                Text("******")
                                    .foregroundColor(.black)
                                Spacer()
                                Image("back")
                            }
                        }
                    }
                }
                .navigationTitle("Password Manager")

                // Floating Action Button at Bottom Right
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button(action: {
                            selectedPassword = nil
                            showAddView.toggle()
                        }) {
                            Image("add")
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 30)
                    }
                }
            }
        }
        .sheet(isPresented: $showAddView) {
            AddPasswordView(passwordEntry: selectedPassword)
                .presentationDetents([.fraction(0.4)]) // 40% of screen height
        }
        .sheet(isPresented: $showDetailsView) {
            if let selectedPassword = selectedPassword {
                AccountDetailView(passwordEntry: selectedPassword, showPassword: $showDetailsView)
                    .environment(\.managedObjectContext, viewContext) // Pass Core Data context
                    .presentationDetents([.fraction(0.4)])
            }
        }

    }

//    private func deletePassword(at offsets: IndexSet) {
//        for index in offsets {
//            viewContext.delete(passwords[index])
//        }
//        PersistenceController.shared.saveContext()
//    }
}

struct PasswordRow: View {
    let title: String
    
    var body: some View {
        HStack {
            Text(title)
                .font(.headline)
            Spacer()
            Text("******")
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(.systemGray6)))
    }
}
