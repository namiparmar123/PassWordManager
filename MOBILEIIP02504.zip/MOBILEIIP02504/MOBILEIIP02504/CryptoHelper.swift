//
//  File.swift
//  MOBILEIIP02504
//
//  Created by Admin on 04/03/25.
//

import CryptoKit
import Foundation

class CryptoHelper {
    static let key = SymmetricKey(size: .bits256)

    static func encrypt(_ text: String) -> String? {
        guard let data = text.data(using: .utf8) else { return nil }
        do {
            let sealedBox = try AES.GCM.seal(data, using: key)
            return sealedBox.combined?.base64EncodedString()
        } catch {
            print("Encryption error: \(error)")
            return nil
        }
    }

    static func decrypt(_ encryptedText: String) -> String? {
        guard let data = Data(base64Encoded: encryptedText) else { return nil }
        do {
            let sealedBox = try AES.GCM.SealedBox(combined: data)
            let decryptedData = try AES.GCM.open(sealedBox, using: key)
            return String(data: decryptedData, encoding: .utf8)
        } catch {
            print("Decryption error: \(error)")
            return nil
        }
    }
}

